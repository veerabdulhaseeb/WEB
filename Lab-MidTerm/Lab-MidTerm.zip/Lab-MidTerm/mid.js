
function handlerLogo(){
    var input1 = document.getElementById("logo");
    alert("SP20-BCS-009")
}